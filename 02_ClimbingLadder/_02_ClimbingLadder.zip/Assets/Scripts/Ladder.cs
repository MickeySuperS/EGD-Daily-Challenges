﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace EGD
{
    public class Ladder : MonoBehaviour
    {
        public float step = 0.35f;
        public float stepWidth = 1f;
    }
}
